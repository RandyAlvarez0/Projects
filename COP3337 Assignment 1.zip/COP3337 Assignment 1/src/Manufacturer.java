/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ralva
 */
public class Manufacturer {
    public String companyName;
    public Address address;
    public String purchaseDate;
    
    /**
     * 
     * @param companyName
     * @param address 
     */
    public Manufacturer(String companyName, Address address) {
        this.companyName = companyName;
        this.address = address;
    }

    /**
     * 
     * @return companyName
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     * 
     * @return capitalized state initials
     */
    public String getAddress() {
        return address.getState();
    }

    /**
     * 
     * @return purchaseDate
     */
    public String getDate() {
        return purchaseDate;
    }

    /**
     * 
     * @param purchaseDate 
     * Set Date
     */
    public void setDate(String purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    

    
    
}
