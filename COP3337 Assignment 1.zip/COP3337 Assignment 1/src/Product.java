/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ralva
 */
public class Product {
    public Manufacturer manufacturer;
    public String name;
    public int quantity;
    public int unitPrice;

  
    /**
     * 
     * @param manufacturer
     * @param name
     * @param quantity
     * @param unitPrice 
     */
    public Product(Manufacturer manufacturer, String name, int quantity, int unitPrice) {
        this.manufacturer = manufacturer;
        this.name = name;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
    }

    /**
     * 
     * @return manufacturer
     */
    public Manufacturer getManufacturer() {
        return manufacturer;
    }

    /**
     * 
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * 
     * @param name 
     * Set name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 
     * @return quantity
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * 
     * @param quantity 
     * Set quantity
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    /**
     * 
     * @return unitPrice
     */
    public int getUnitPrice() {
        return unitPrice;
    }

    /**
     * 
     * @param unitPrice 
     * Set UnitPrice
     */
    public void setUnitPrice(int unitPrice) {
        this.unitPrice = unitPrice;
    }
    
    /**
     * 
     * @return formatted product list string
     */
    @Override
    public String toString(){
        
        String toString = name + "                    " + manufacturer.getDate() + "                    " + quantity
        + "                    " + unitPrice + "                    " + manufacturer.getCompanyName() + "                    " +
        manufacturer.getAddress();
        
        return toString;
    }
    
    /**
     * 
     * @return formatted deleted product list string
     */
    public String deletedToString(){
        
        String toString = name + "                    " + manufacturer.getDate()+ "                    " 
                + manufacturer.getCompanyName() + "                    " ;
        
        return toString;
    }
    
}
