

import java.util.ArrayList;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ralva
 */
public class testMain{
    
     
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //ArrayList to store created products and deleted products
        ArrayList<Product> productsList = new ArrayList<>(); 
        ArrayList<Product> deletedProduct = new ArrayList<>(); 
        
        //Database object that holds both product list
        Database database = new Database(productsList, deletedProduct);
        
        //Boolean parameter for while loop
        boolean loop = true;

        //String to be displayed by JOptionPane
        String message = "1) Inventory Report\n" 
                       + "2) Update Quantity\n" 
                       + "3) Update Unit Price\n"
                       + "4) Create Product\n"
                       + "5) Remove Product\n"
                       + "6) Locate Product\n"
                       + "7) Deleted Inventory";
        
        while(loop){
            //Inital message
            String res = JOptionPane.showInputDialog(message);
             
        if(Integer.parseInt(res) == 1){
            
            if(database.getProductList().isEmpty()){
                JOptionPane.showMessageDialog(
                        null, "Inventory is empty", 
                        "Info", JOptionPane.WARNING_MESSAGE);
                
            }else{
                //Format for iventory display
                JOptionPane.showMessageDialog(null, "Product" + "       " 
                        + "Purchase Date" + "       " + "Quantity" 
                        + "     " + "Price" + "       " + "Manufacturer" + "    " 
                        + "State" + "       \n" + database.getInventory());
                                                 
            }
            
        }else if(Integer.parseInt(res) == 2){
                       
            if(database.getProductList().isEmpty()){
                JOptionPane.showMessageDialog(
                        null, "Inventory is empty", 
                        "Info", JOptionPane.WARNING_MESSAGE);
                
            }else{
                //String to hold product name
                String proName = JOptionPane.showInputDialog(
                                            "Enter Product Name");
             
                //Search database for a matching product name
                //Store the parsed int, find the product by its name and set it quantity
                if(database.search(proName)){
                    int newQuantity = Integer.parseInt(
                                    (JOptionPane.showInputDialog(
                                            "Set Quantity for Product")));
                    
                    database.getProductByName(proName).setQuantity(newQuantity);
                 
                }else{
                    JOptionPane.showMessageDialog(
                            null, "Product is not in Iventory", 
                            "Info", JOptionPane.INFORMATION_MESSAGE);
                }
            
            }
            
        }else if(Integer.parseInt(res) == 3){
            
            if(database.getProductList().isEmpty()){
               JOptionPane.showMessageDialog(
                       null, "Inventory is empty", 
                       "Info",JOptionPane.WARNING_MESSAGE);
                
            }else{
                //String to hold product name
                String proName = JOptionPane.showInputDialog(
                                            "Enter Product Name");
             
                //Search database for a matching product name
                //Store the parsed int, find the product by its name and set it price
                if(database.search(proName)){
                    int newPrice = Integer.parseInt(
                            (JOptionPane.showInputDialog(
                                    "Set Unit Price for Product")));
                    
                    database.getProductByName(proName).setUnitPrice(newPrice);
                 
                }else{
                    JOptionPane.showMessageDialog(
                            null, "Product is not in Iventory", 
                            "Info", JOptionPane.INFORMATION_MESSAGE);
                }

            }
            
        }else if(Integer.parseInt(res) == 4){
            
            //Create Address object with string returned
            Address companyAddress = new Address(
                    JOptionPane.showInputDialog("Enter Comapny State Initals")); 
            
            //Create Manufacturer object with Address object and string returned
            Manufacturer manu = new Manufacturer(
                    JOptionPane.showInputDialog("Enter Company Name"), companyAddress);
            
            //Set the purchase date
            manu.setDate(JOptionPane.showInputDialog("Set Purchase Date"));

            //Create product object
            Product newProduct = new Product(manu, 
                JOptionPane.showInputDialog("Enter Product Name"),
                Integer.parseInt(JOptionPane.showInputDialog("Enter Qauntity")),
                Integer.parseInt(JOptionPane.showInputDialog("Enter Unit Price")));
                
            //Add the product to the database
            database.addPro(newProduct);
                              
        }else if(Integer.parseInt(res) == 5){
           
            if(database.getProductList().isEmpty()){
                JOptionPane.showMessageDialog(
                        null, "Inventory is empty", 
                        "Info", JOptionPane.WARNING_MESSAGE);
                
            }else{
                //String to hold product name to remove
                String rem = JOptionPane.showInputDialog(
                                        "Product Name to Remove");

                //Remove the product from the list
                database.remove(rem);
                
                //Display info message
                JOptionPane.showMessageDialog(
                        null, "Product has been removed", 
                        "Info", JOptionPane.INFORMATION_MESSAGE);
            }
         
            
        }else if(Integer.parseInt(res) == 6){
            
            if(database.getProductList().isEmpty()){
                JOptionPane.showMessageDialog(
                        null, "Inventory is empty", 
                        "Info", JOptionPane.WARNING_MESSAGE);
                
            }else{
                //String to hold product name to locate
                String proName = JOptionPane.showInputDialog(
                                            "Product Name To Locate");
                
                //Search database for a matching product name
                if(database.search(proName)){
                    
                    //Format for located product display
                        JOptionPane.showMessageDialog(
                            null, "Product" + " "  + "Quantity" + " " + "Price\n" 
                            + database.getProductByName(proName).getName()
                            + "      " 
                            + database.getProductByName(proName).getQuantity() 
                            + "      " + 
                    String.valueOf(database.getProductByName(proName).getUnitPrice()));
                    
                }else{
                    JOptionPane.showMessageDialog(
                            null, "Product is not in Iventory", 
                            "Info", JOptionPane.INFORMATION_MESSAGE);
                }
                
            }
            
            
        }else if(Integer.parseInt(res) == 7){
            
            if(database.getDeletedProductList().isEmpty()){
                JOptionPane.showMessageDialog(
                        null, "Inventory is empty", 
                        "Info", JOptionPane.WARNING_MESSAGE);
                
            }else{
                
                //Format for deleted products display
                JOptionPane.showMessageDialog(null, "Product" + "   " 
                        + "Purchase Date" + "   " + "Manufacturer" + "   " 
                        + "       \n" + database.getDeletedInventory());
            }
            
        }
        
        }
        
   }
    
}
