/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ralva
 */
public class Address {
    public String stateInit;
  
    /**
     * 
     * @param state 
     */
    public Address(String state) {
        this.stateInit = state;
       
    }
    
    /**
     * 
     * @return capitalized initials
     */
    public String getState() {
        return stateInit.toUpperCase();
    }

   
 
    
}
