
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ralva
 */
public class Database {
    public ArrayList<Product> productList;
    public ArrayList<Product> deletedProduct;
    
    /**
     * 
     * @param product
     * @param deletedproduct 
     */
    public Database(ArrayList<Product> product, ArrayList<Product> deletedproduct){
        this.productList = product;
        this.deletedProduct = deletedproduct;
    }
    
    /**
     * 
     * @param product 
     * Add to the productList 
     */
    public void addPro(Product product){
        productList.add(product);
    }
    
    /**
     * 
     * @param product 
     * Add to deletedProduct & remove from productList
     */
    public void remove(String product){

        for(int i = 0; i < productList.size(); i++){
            if(productList.get(i).getName().equals(product) ){
                
                   deletedProduct.add(productList.get(i));
                   productList.remove(i);
                
                
            }
        }
    }

    /**
     * 
     * @return concatenated string of products in productList
     */
    public String getInventory(){
        
            String display = "";
            for(int i = 0; i < productList.size(); i++){
                display += productList.get(i).toString() + " \n";
            }
        return display;
    }
    
    /**
     * 
     * @return concatenated string of products in deletedProduct
     */
    public String getDeletedInventory(){
        
            String display = "";
            for(int i = 0; i < deletedProduct.size(); i++){
                display += deletedProduct.get(i).deletedToString() + " \n";
            }
        return display;
    }
     
    /**
     * 
     * @param name
     * @return product matching parameter 
     */
    public Product getProductByName(String name){
            for(int i = 0; i < productList.size(); i++){
                if(productList.get(i).getName().equalsIgnoreCase(name)){
                    return productList.get(i);
                }else{
                    return null;
                }
            }
        return null;
    }
    
    /**
     * 
     * @param name
     * @return true if parameter is in productList, else false
     */
    public Boolean search(String name){
        for(int i = 0; i < productList.size(); i++){
            if(productList.get(i).getName().equals(name)){
                return true;
              
            }else{
                return false;
            }
        }
       return false;
    }
    
    /**
     * 
     * @return productList
     */
    public ArrayList<Product> getProductList() {
        
        return productList;
    }

    /**
     * 
     * @return deletedProduct
     */
    public ArrayList<Product> getDeletedProductList() {
        
        return deletedProduct;
    }
    
    /**
     * 
     * @param index
     * @return product by index
     */
    public Product getProduct(int index){
       
        return productList.get(index);
    }

    /**
     * 
     * @param index
     * @return deleted product by index
     */
    public Product getDeletedProduct(int index){
        
        return deletedProduct.get(index);
        
    }
}
